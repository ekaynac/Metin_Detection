
Büyülü Orman Metinleri - v1 buyulu_orman_metinleri_dataset
==============================

This dataset was exported via roboflow.ai on February 9, 2022 at 4:05 AM GMT

It includes 114 images.
Metin are annotated in Tensorflow Object Detection format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)
* Auto-contrast via adaptive equalization

The following augmentation was applied to create 3 versions of each source image:
* Randomly crop between 0 and 20 percent of the image
* Random rotation of between -15 and +15 degrees


